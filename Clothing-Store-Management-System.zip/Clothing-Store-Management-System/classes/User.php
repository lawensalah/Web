<?php
// classes/User.php

class User {
    public $id;
    public $username;
    public $email;
    public $role;

    public function __construct($id, $username, $email, $role = 'staff') {
        $this->id       = $id;
        $this->username = $username;
        $this->email    = $email;
        $this->role     = $role;
    }

    // Register a new user
    public static function register($username, $email, $password) {
        global $pdo;

        // Check if username or email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
        $stmt->execute(['username' => $username, 'email' => $email]);
        if ($stmt->fetch()) {
            return false;
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
        return $stmt->execute(['username' => $username, 'email' => $email, 'password' => $hashedPassword]);
    }

    // Fetch a user by username
    public static function getByUsername($username) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username LIMIT 1");
        $stmt->execute(['username' => $username]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    // In User.php
public static function getAllUsers(): array {
    $db = new Database();
    $pdo = $db->getConnection();
    
    try {
        $stmt = $pdo->query("SELECT id, username, email, role FROM users");
        return array_map(function($userData) {
            return new User(
                (int)$userData['id'],
                $userData['username'],
                $userData['email'],
                $userData['role']
            );
        }, $stmt->fetchAll(PDO::FETCH_ASSOC));
    } catch (PDOException $e) {
        error_log("Get users error: " . $e->getMessage());
        return [];
    }
}

public static function getById(int $id): ?User {
    $db = new Database();
    $pdo = $db->getConnection();
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $userData ? new User(
            (int)$userData['id'],
            $userData['username'],
            $userData['email'],
            $userData['role']
        ) : null;
    } catch (PDOException $e) {
        error_log("Get user error: " . $e->getMessage());
        return null;
    }
}

public static function updateUser(int $id, array $data): bool {
    $db = new Database();
    $pdo = $db->getConnection();
    
    try {
        $updates = [];
        $params = [':id' => $id];
        
        if (isset($data['email'])) {
            $updates[] = "email = :email";
            $params[':email'] = $data['email'];
        }
        
        if (isset($data['role'])) {
            $updates[] = "role = :role";
            $params[':role'] = $data['role'];
        }
        
        if (empty($updates)) return false;
        
        $stmt = $pdo->prepare("
            UPDATE users 
            SET " . implode(', ', $updates) . " 
            WHERE id = :id
        ");
        
        return $stmt->execute($params);
    } catch (PDOException $e) {
        error_log("Update user error: " . $e->getMessage());
        return false;
    }
}

public static function deleteUser(int $id): bool {
    $db = new Database();
    $pdo = $db->getConnection();
    
    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    } catch (PDOException $e) {
        error_log("Delete user error: " . $e->getMessage());
        return false;
    }
}
}

?>
